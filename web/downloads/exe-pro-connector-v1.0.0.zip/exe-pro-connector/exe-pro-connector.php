<?php
/**
 * Plugin Name: EXE PRO Connector
 * Description: Conecta o WordPress ao EXE PRO para monitoramento, suspensão temporária e reativação segura do site.
 * Version: 1.0.0
 * Author: EXEKUTA
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class EXE_PRO_Connector {
    const VERSION = '1.0.0';
    const OPTION_KEY = 'exe_pro_connector_settings';
    const NOTICE_KEY = 'exe_pro_connector_admin_notice';
    const REST_NS = 'exe-pro/v1';

    public static function init() {
        register_activation_hook( __FILE__, array( __CLASS__, 'activate' ) );
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
        add_action( 'template_redirect', array( __CLASS__, 'maybe_suspend_frontend' ), 0 );
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
        add_action( 'admin_post_exe_pro_connector_save', array( __CLASS__, 'admin_save' ) );
        add_action( 'admin_post_exe_pro_connector_resume', array( __CLASS__, 'admin_resume' ) );
        add_action( 'admin_post_exe_pro_connector_regenerate', array( __CLASS__, 'admin_regenerate_key' ) );
        add_action( 'admin_notices', array( __CLASS__, 'admin_notice' ) );
    }

    public static function activate() {
        $settings = get_option( self::OPTION_KEY, array() );
        if ( empty( $settings['secret'] ) ) {
            $settings['secret'] = self::generate_secret();
        }
        $settings = wp_parse_args( $settings, self::defaults() );
        update_option( self::OPTION_KEY, $settings, false );
    }

    private static function defaults() {
        return array(
            'secret'               => '',
            'allow_remote_control' => 1,
            'suspended'            => 0,
            'suspend_mode'         => '',
            'suspended_at'         => '',
            'message_title'        => 'Site temporariamente indisponível',
            'message_body'         => 'Este site está temporariamente indisponível. Tente novamente mais tarde.',
            'retry_after'          => 3600,
            'last_remote_action'   => '',
            'last_remote_at'       => '',
        );
    }

    private static function settings() {
        return wp_parse_args( get_option( self::OPTION_KEY, array() ), self::defaults() );
    }

    private static function save_settings( $settings ) {
        update_option( self::OPTION_KEY, wp_parse_args( $settings, self::defaults() ), false );
    }

    private static function generate_secret() {
        try {
            return bin2hex( random_bytes( 32 ) );
        } catch ( Exception $e ) {
            return wp_generate_password( 64, false, false );
        }
    }

    public static function register_routes() {
        register_rest_route(
            self::REST_NS,
            '/status',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( __CLASS__, 'rest_status' ),
                'permission_callback' => array( __CLASS__, 'verify_request' ),
            )
        );

        register_rest_route(
            self::REST_NS,
            '/suspend',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( __CLASS__, 'rest_suspend' ),
                'permission_callback' => array( __CLASS__, 'verify_request' ),
            )
        );

        register_rest_route(
            self::REST_NS,
            '/resume',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( __CLASS__, 'rest_resume' ),
                'permission_callback' => array( __CLASS__, 'verify_request' ),
            )
        );
    }

    public static function verify_request( WP_REST_Request $request ) {
        $settings = self::settings();
        $secret   = (string) $settings['secret'];

        if ( '' === $secret ) {
            return new WP_Error( 'exe_pro_no_key', 'Chave de conexão não configurada.', array( 'status' => 503 ) );
        }

        $timestamp = (string) $request->get_header( 'x-exe-timestamp' );
        $nonce     = (string) $request->get_header( 'x-exe-nonce' );
        $signature = strtolower( (string) $request->get_header( 'x-exe-signature' ) );

        if ( ! ctype_digit( $timestamp ) || abs( time() - (int) $timestamp ) > 300 ) {
            return new WP_Error( 'exe_pro_timestamp', 'Assinatura expirada.', array( 'status' => 401 ) );
        }

        if ( ! preg_match( '/^[a-zA-Z0-9_-]{16,100}$/', $nonce ) ) {
            return new WP_Error( 'exe_pro_nonce', 'Nonce inválido.', array( 'status' => 401 ) );
        }

        $transient = 'exe_pro_nonce_' . substr( hash( 'sha256', $nonce ), 0, 40 );
        if ( get_transient( $transient ) ) {
            return new WP_Error( 'exe_pro_replay', 'Requisição repetida.', array( 'status' => 409 ) );
        }

        $body       = (string) $request->get_body();
        $body_hash  = hash( 'sha256', $body );
        $canonical  = $timestamp . "\n" . $nonce . "\n" . strtoupper( $request->get_method() ) . "\n" . $request->get_route() . "\n" . $body_hash;
        $expected   = hash_hmac( 'sha256', $canonical, $secret );

        if ( ! hash_equals( $expected, $signature ) ) {
            return new WP_Error( 'exe_pro_signature', 'Assinatura inválida.', array( 'status' => 401 ) );
        }

        set_transient( $transient, 1, 10 * MINUTE_IN_SECONDS );
        return true;
    }

    public static function rest_status() {
        $settings = self::settings();
        return rest_ensure_response(
            array(
                'ok'                   => true,
                'plugin'               => 'EXE PRO Connector',
                'version'              => self::VERSION,
                'wordpress_version'    => get_bloginfo( 'version' ),
                'site_url'             => site_url(),
                'home_url'             => home_url(),
                'suspended'            => (bool) $settings['suspended'],
                'suspend_mode'         => (string) $settings['suspend_mode'],
                'suspended_at'         => (string) $settings['suspended_at'],
                'allow_remote_control' => (bool) $settings['allow_remote_control'],
                'last_remote_action'   => (string) $settings['last_remote_action'],
                'last_remote_at'       => (string) $settings['last_remote_at'],
            )
        );
    }

    public static function rest_suspend( WP_REST_Request $request ) {
        $settings = self::settings();
        if ( empty( $settings['allow_remote_control'] ) ) {
            return new WP_Error( 'exe_pro_remote_disabled', 'Controle remoto desativado no WordPress.', array( 'status' => 403 ) );
        }

        $data = $request->get_json_params();
        if ( ! is_array( $data ) ) {
            $data = array();
        }

        $settings['suspended']          = 1;
        $settings['suspend_mode']       = sanitize_key( isset( $data['mode'] ) ? $data['mode'] : 'manual' );
        $settings['suspended_at']       = gmdate( 'c' );
        $settings['message_title']      = sanitize_text_field( isset( $data['title'] ) ? $data['title'] : $settings['message_title'] );
        $settings['message_body']       = sanitize_textarea_field( isset( $data['message'] ) ? $data['message'] : $settings['message_body'] );
        $settings['retry_after']        = max( 60, min( 86400, absint( isset( $data['retry_after'] ) ? $data['retry_after'] : 3600 ) ) );
        $settings['last_remote_action'] = 'suspend';
        $settings['last_remote_at']     = gmdate( 'c' );
        self::save_settings( $settings );

        return self::rest_status();
    }

    public static function rest_resume() {
        $settings = self::settings();
        if ( empty( $settings['allow_remote_control'] ) ) {
            return new WP_Error( 'exe_pro_remote_disabled', 'Controle remoto desativado no WordPress.', array( 'status' => 403 ) );
        }

        $settings['suspended']          = 0;
        $settings['suspend_mode']       = '';
        $settings['suspended_at']       = '';
        $settings['last_remote_action'] = 'resume';
        $settings['last_remote_at']     = gmdate( 'c' );
        self::save_settings( $settings );

        return self::rest_status();
    }

    public static function maybe_suspend_frontend() {
        if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
            return;
        }

        if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
            return;
        }

        $settings = self::settings();
        if ( empty( $settings['suspended'] ) ) {
            return;
        }

        status_header( 503 );
        nocache_headers();
        header( 'Retry-After: ' . max( 60, absint( $settings['retry_after'] ) ) );
        header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );

        $title   = esc_html( $settings['message_title'] );
        $message = nl2br( esc_html( $settings['message_body'] ) );
        ?>
        <!doctype html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo( 'charset' ); ?>">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <meta name="robots" content="noindex,nofollow">
            <title><?php echo $title; ?></title>
            <style>
                html,body{min-height:100%;margin:0;background:#0d0f12;color:#fff;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
                body{display:grid;place-items:center;padding:24px;box-sizing:border-box}
                .exe-pro-maintenance{width:min(680px,100%);background:#15181d;border:1px solid #2b3139;border-radius:20px;padding:38px;box-sizing:border-box;box-shadow:0 24px 80px rgba(0,0,0,.35)}
                .exe-pro-mark{display:inline-flex;align-items:center;gap:9px;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#67e8d2;margin-bottom:18px}
                .exe-pro-dot{width:10px;height:10px;border-radius:50%;background:#18b7a4;box-shadow:0 0 0 5px rgba(24,183,164,.12)}
                h1{font-size:clamp(28px,5vw,46px);line-height:1.05;margin:0 0 14px}
                p{font-size:17px;line-height:1.65;color:#c7cbd1;margin:0}
            </style>
        </head>
        <body>
            <main class="exe-pro-maintenance">
                <div class="exe-pro-mark"><span class="exe-pro-dot"></span> Manutenção temporária</div>
                <h1><?php echo $title; ?></h1>
                <p><?php echo $message; ?></p>
            </main>
        </body>
        </html>
        <?php
        exit;
    }

    public static function admin_menu() {
        add_options_page(
            'EXE PRO Connector',
            'EXE PRO Connector',
            'manage_options',
            'exe-pro-connector',
            array( __CLASS__, 'admin_page' )
        );
    }

    public static function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $s = self::settings();
        ?>
        <div class="wrap">
            <h1>EXE PRO Connector</h1>
            <p>Conecte este WordPress ao EXE PRO sem compartilhar usuário ou senha administrativa.</p>

            <table class="widefat striped" style="max-width:900px;margin:18px 0">
                <tbody>
                    <tr><th style="width:240px">Status do site</th><td><strong><?php echo ! empty( $s['suspended'] ) ? 'Temporariamente suspenso' : 'Ativo'; ?></strong></td></tr>
                    <tr><th>Endpoint</th><td><code><?php echo esc_html( rest_url( self::REST_NS . '/status' ) ); ?></code></td></tr>
                    <tr><th>Chave de conexão</th><td><input type="text" readonly onclick="this.select()" value="<?php echo esc_attr( $s['secret'] ); ?>" style="width:100%;font-family:monospace"></td></tr>
                    <tr><th>Versão</th><td><?php echo esc_html( self::VERSION ); ?></td></tr>
                </tbody>
            </table>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:900px">
                <?php wp_nonce_field( 'exe_pro_connector_save' ); ?>
                <input type="hidden" name="action" value="exe_pro_connector_save">
                <h2>Controle remoto</h2>
                <p><label><input type="checkbox" name="allow_remote_control" value="1" <?php checked( ! empty( $s['allow_remote_control'] ) ); ?>> Permitir que o EXE PRO suspenda e reative este site.</label></p>
                <table class="form-table">
                    <tr><th><label for="message_title">Título padrão</label></th><td><input class="regular-text" id="message_title" name="message_title" value="<?php echo esc_attr( $s['message_title'] ); ?>"></td></tr>
                    <tr><th><label for="message_body">Mensagem padrão</label></th><td><textarea class="large-text" rows="4" id="message_body" name="message_body"><?php echo esc_textarea( $s['message_body'] ); ?></textarea></td></tr>
                </table>
                <?php submit_button( 'Salvar configurações' ); ?>
            </form>

            <hr style="max-width:900px;margin:30px 0">
            <h2>Emergência / manutenção</h2>
            <p>Estas ações funcionam localmente mesmo que o EXE PRO Cloud esteja indisponível.</p>
            <p>
                <a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=exe_pro_connector_resume' ), 'exe_pro_connector_resume' ) ); ?>">Reativar site agora</a>
                <a class="button" onclick="return confirm('Gerar uma nova chave desconecta a chave cadastrada atualmente no EXE PRO. Continuar?')" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=exe_pro_connector_regenerate' ), 'exe_pro_connector_regenerate' ) ); ?>">Gerar nova chave</a>
            </p>
        </div>
        <?php
    }

    public static function admin_save() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Sem permissão.' );
        }
        check_admin_referer( 'exe_pro_connector_save' );
        $s = self::settings();
        $s['allow_remote_control'] = isset( $_POST['allow_remote_control'] ) ? 1 : 0;
        $s['message_title'] = sanitize_text_field( wp_unslash( isset( $_POST['message_title'] ) ? $_POST['message_title'] : '' ) );
        $s['message_body'] = sanitize_textarea_field( wp_unslash( isset( $_POST['message_body'] ) ? $_POST['message_body'] : '' ) );
        self::save_settings( $s );
        self::set_notice( 'Configurações salvas.' );
        wp_safe_redirect( admin_url( 'options-general.php?page=exe-pro-connector' ) );
        exit;
    }

    public static function admin_resume() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Sem permissão.' );
        }
        check_admin_referer( 'exe_pro_connector_resume' );
        $s = self::settings();
        $s['suspended'] = 0;
        $s['suspend_mode'] = '';
        $s['suspended_at'] = '';
        self::save_settings( $s );
        self::set_notice( 'Site reativado localmente.' );
        wp_safe_redirect( admin_url( 'options-general.php?page=exe-pro-connector' ) );
        exit;
    }

    public static function admin_regenerate_key() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Sem permissão.' );
        }
        check_admin_referer( 'exe_pro_connector_regenerate' );
        $s = self::settings();
        $s['secret'] = self::generate_secret();
        self::save_settings( $s );
        self::set_notice( 'Nova chave gerada. Atualize a conexão no EXE PRO.' );
        wp_safe_redirect( admin_url( 'options-general.php?page=exe-pro-connector' ) );
        exit;
    }

    private static function set_notice( $message ) {
        set_transient( self::NOTICE_KEY, sanitize_text_field( $message ), 60 );
    }

    public static function admin_notice() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $notice = get_transient( self::NOTICE_KEY );
        if ( $notice ) {
            delete_transient( self::NOTICE_KEY );
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $notice ) . '</p></div>';
        }
    }
}

EXE_PRO_Connector::init();
